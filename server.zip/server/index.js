const express =require('express');
const cors =require('cors');
const {MongoClient}=require('mongodb');
const bcrypt=require('bcrypt');
const req = require('express/lib/request');
const res = require('express/lib/response');

//object
const app=new express();
app.use(express.json());
app.use(cors());
// request and response
app.get('/home',(req,res)=> {
    res.send("my home page")
})   
const client=new MongoClient('mongodb+srv://admin1:admin1@cluster0.v7uwxpk.mongodb.net/?retryWrites=true&w=majority')

client.connect();
const db = client.db('cvms'); 

const col = db.collection('register');

app.post('/insert',async(req,res)=> {
    console.log(req.body);
    req.body.password=await bcrypt.hash(req.body.password,8)
    col.insertOne(req.body);
    res.send("successfully received")
})
app.get('/showall',async(req,res)=> {
    const result=await col.find().toArray();
    res.send(result)
})


app.post('/delete',async(req,res)=>{
    console.log("checking")
    const result1=await col.findOne({'name':req.body.un})
    console.log(result1)
    if (result1.password==req.body.pw)
    col.deleteOne(result1);
})
app.post('/check',async(req,res)=>{
    const result2=await col.findOne({'name':req.body.un})
    if (result2.password==req.body.pw)
    res.send(result2);
    else if(await bcrypt.compare(req.body.pw,result2.password)){
        res.send(result2)
    }
    else
    res.send("false")
})

app.post('/update',async(req,res)=> {
    console.log(req.body);
    const {un,pw,ro,em}=req.body;
    await col.updateOne({name:un},{
     $set:{
         password:pw,
         role:ro,
         email:em
     }
    })
  })



  app.post('/Product',async(req,res)=> {
    console.log(Image);
    ImageData=await insertOne.hash(Image,10)
    col.insertOne(ImageData);
    res.send("Inserted")
})
app.listen(8081,()=>{console.log("server running")});