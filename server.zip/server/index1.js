const express =require('express');
const cors = require('cors');
const { MongoClient } = require('mongodb');

const app = new express();
app.use(express.json());
app.use(cors());


app.listen(8081,()=>{console.log("server running")});